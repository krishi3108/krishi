#include<stdio.h>
int main()
{
	float c,f;
	c=32;
	f=((9*c)/5)+32;
	printf("%f",f);
	return 1;
}	